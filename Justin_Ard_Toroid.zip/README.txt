Justin Ard
ard@wsu.edu
cs442
homework 3 - toroid spiral

This archive contains my implementation of the 3D toroid spiral.  It can
be rendered to show only the spine, the wire frame model, or the filled
and shaded model.

This program is implemented in java using the Java Bindings for 
OpenGL (JOGL). In order to run this program you must first install 
the JOGL libraries. The necessary files can be downloaded from 

http://jogamp.org/deployment/webstart/archive/

In order to compile this program you must have the jogl.all.jar and
gluegen.jar files visible to the java compiler classpath.  These files
are stored at /jogamp-<your_platform>-<your_processor_type>/jar/

One these files are in your classpath, you can compile the program:
e.g.,
export CLASSPATH="$CLASSPATH:/jogamp-<your_platform>-<your_processor_type>/jar/jogl.all.jar"
export CLASSPATH="$CLASSPATH:/jogamp-<your_platform>-<your_processor_type>/jar/gluegen.jar"
javac Toroid.java

In order to run this program you must have the local directory and the 
jogl lib folder visible to the java library path.  This folder is 
located at /jogamp-<your_platform>-<your_processor_type>/lib

You can then run the Toroid program with 0 or more arguments.
e.g.,
export CLASSPATH="$CLASSPATH:."
export CLASSPATH="$CLASSPATH:"/jogamp-<your_platform>-<your_processor_type>/lib"
java Toroid [options]

The available options at runtime include:
-a NUM,		set the main radius to the float value NUM
-b NUM,		set the spiral radius to the float value NUM
-r NUM,		set the tube radius to the float value NUM
-q NUM,		set the number of coils to the int value NUM
-p NUM,		set the number of winds around the origin to the int value NUM
-n NUM,		set the number of spine samples to the int value NUM
-m NUM,		set the number of cross section samples to the int value NUM

The default values (used if no arguments are given) are:
a = 100.0
b = 40.0
r = 20.0
q = 7
p = 1
n = 100
m = 32

Once running, the program will display a 3d, shaded rendering
of the spiral toroid using the given parameters.  While running,
you can change the display by using the following keys:

1	render the spine
2	render the wire frame mesh
3	render the filled mesh
z	zoom out (move camera away from view point)
x	zoom in (move camera towards view point)
w	move camera up (positive y axis)
s	move camera down (negative y axis)
a	move the camera left (negative x axis)
d	move the camera right (positive x axis)

You can also rotate the toroid by clicking on the canvas and
dragging left/right or up/down.

You can end the program by pressing the escape key or closing the window.


Files included in this archive:

Toroid.java - a java source file which draws the toroid
